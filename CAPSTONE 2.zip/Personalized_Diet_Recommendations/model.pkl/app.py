from flask import Flask, render_template, request
import pickle
import numpy as np

app = Flask(__name__)

# Load the trained model
with open('model.pkl', 'rb') as f:
    model = pickle.load(f)

@app.route('/predict', methods=['POST'])
def predict():
    try:
        # Get form data
        age = int(request.form['age'])
        gender = int(request.form['gender'])
        weight = int(request.form['weight'])
        height = int(request.form['height'])
        cholesterol = int(request.form['cholesterol'])
        blood_pressure = int(request.form['blood_pressure'])
        region = int(request.form['region_encoded'])
        dietary = int(request.form['dietary_habit'])
        activity = int(request.form['activity_level'])

        # Prepare input
        features = np.array([[age, gender, weight, height, cholesterol,
                              blood_pressure, region, dietary, activity]])

        prediction = model.predict(features)[0]

        # Map number to label
        diet_map = {
            0: "Diabetic Friendly Diet",
            1: "High Protein Diet",
            2: "Balanced Diet",
            3: "Low Carb Diet"
        }

        diet_name = diet_map.get(int(prediction), "Unknown")

        # Render result page
        return render_template("result.html", prediction=prediction, diet_name=diet_name)

    except Exception as e:
        return f"Error: {str(e)}"

